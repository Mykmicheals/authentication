from django.shortcuts import render, redirect
from django.urls import reverse
from django.contrib.auth.models import User
from django.contrib import messages
from django.core.mail import EmailMessage
from django.utils.encoding import force_bytes,force_text,DjangoUnicodeDecodeError
from django.utils.http import urlsafe_base64_encode,urlsafe_base64_decode
from django.contrib.sites.shortcuts import get_current_site

def index (request):
    return render (request,'app/index.html')

def sign_up(request):
    if request.method =='POST':
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        if password1 == password2:
            print(password2)
            if User.objects.filter(username=username).exists():
                messages.warning(request, 'Username exists')
                return redirect('/sign_up')
            elif User.objects.filter(email=email).exists():
                messages.warning(request, 'Email exists')
            else:
                user = User.objects.create_user(username=username,password=password2)
                user.is_active = False
                user.save()
                uidb64=force_bytes(urlsafe_base64_encode(user.pk))
                domain = get_current_site(request).domain
                link = reverse('activate',kwargs={'uidb64':uidb64, 'token':token})
                email_subject = 'activate your account'
                email_body = 'welcome'
                email = EmailMessage(
                    email_subject,
                    email_body,
                    'noReply@cybsec.com',
                    [email]

                )
                email.send(fail_silently=False)
        else:
            messages.warning(request, 'password doesnt match')
            return redirect('/sign_up')
    return render (request,'app/sign_up.html')

def activate(request,self,uidb64,token):
    pass
            
